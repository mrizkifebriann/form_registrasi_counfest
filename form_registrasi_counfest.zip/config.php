<?php
$server = 'localhost';
$username = 'root';
$password = '';
$db = 'lomba_counfest';
